package com.board.service;

import java.util.ArrayList;

import com.board.vo.*;

public interface BoardService {
	public ArrayList<BoardVO> selectAll(); 
	public BoardVO selectByNum(String num);
	public int insertBoard(BoardVO u);     
	public int deleteByNum(String num, String pass);
	public int updateBoard(String num, String pass, String title, String content);
	public ArrayList<BoardVO> selectByCondition(String parameter, String parameter2);
	public int updateConter(String num);
}

package com.user.dao;

import java.sql.*;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.user.service.UserService;
import com.user.vo.User;

//process bean : DB process
public class UserDAO implements UserService {
	String url = "jdbc:mariadb://127.0.0.1:3306/TESTDB";
	String user = "dev";
	String pass = "dev";
	
	Connection con = null;
	Statement stat = null;
	PreparedStatement ps = null;
	DataSource ds;

	public UserDAO() {
		try {
			InitialContext context = new InitialContext();
			ds = (DataSource) context.lookup("java:comp/env/jdbc/mariadb");
			Class.forName("org.mariadb.jdbc.Driver");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<User> selectAll() {
		ArrayList<User> lis = new ArrayList<User>();
		try {

			con = ds.getConnection();
			stat = con.createStatement();
			String sql = "SELECT ID, NAME FROM USERS ORDER BY ID";
			ResultSet rs = stat.executeQuery(sql);
			while (rs.next()) {
				String id = rs.getString(1);
				String name = rs.getString(2);

				User user = new User(id, name);
				lis.add(user);
			}
			stat.close();
			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lis;
	}

	public User selectById(String iid) {
		User user = null;
		try {

			con = ds.getConnection();
			stat = con.createStatement();
			String sql = "select id, name, phone, address, company from users9 where id='" + iid + "'";
			ResultSet rs = stat.executeQuery(sql);

			while (rs.next()) {
				String id = rs.getString(1);
				String name = rs.getString(2);
				String phone = rs.getString(3);
				String address = rs.getString(4);
				String company = rs.getString(5);
				user = new User(id, name, phone, address, company);
			}
			stat.close();
			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}

	public ArrayList<User> selectByCondition(String condition, String word) {
		ArrayList<User> lis = new ArrayList<User>();
		try {

			con = ds.getConnection();
			stat = con.createStatement();
			System.out.println("Open!!");
			String sql = "";
			if (condition.equals("address") == true) {
				sql = "select id, name, phone, address, company from users where address='" + word + "'";
			} else {
				sql = "select id, name, phone, address, company from users where company='" + word + "'";
			}

			ResultSet rs = stat.executeQuery(sql);
			while (rs.next()) {
				String id = rs.getString(1);
				String name = rs.getString(2);
				String phone = rs.getString(3);
				String address = rs.getString(4);
				String company = rs.getString(5);
				User user = new User(id, name, phone, address, company);
				lis.add(user);
			}
			stat.close();
			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lis;
	}

	public ArrayList<User> selectByCondition2(String condition, String word) {
		ArrayList<User> lis = new ArrayList<User>();
		try {

			con = ds.getConnection();
			// stat = con.createStatement();
			System.out.println("Open!!");
			String sql = "";
			ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

			sql = "select id, name, phone, address, company from users where " + condition + "= ?";

			ps.setString(1, word);
			ResultSet rs = ps.executeQuery(sql);
			while (rs.next()) {
				String id = rs.getString(1);
				String name = rs.getString(2);
				String phone = rs.getString(3);
				String address = rs.getString(4);
				String company = rs.getString(5);
				User user = new User(id, name, phone, address, company);
				lis.add(user);
			}
			stat.close();
			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lis;
	}

	public int insertUser(User us) {

		try {
			con = ds.getConnection();

			stat = con.createStatement();
			System.out.println("Open!!");
			String sql = "insert into users values(?,?,?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, us.getId());
			ps.setString(2, us.getName());
			ps.setString(3, us.getPhone());
			ps.setString(4, us.getAddress());
			ps.setString(5, us.getCompany());

			int a = ps.executeUpdate();
			System.out.println();
			stat.close();
			con.close();
			return a;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;

	}

	public int deleteById(String iid) {

		try {
			con = ds.getConnection();

			stat = con.createStatement();
			String sql = "delete users where id=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, iid);

			int a = ps.executeUpdate();
			System.out.println();
			stat.close();
			con.close();
			return a;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;

	}
	

}

package com.board.dao;

import java.sql.*;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.board.service.BoardService;
import com.board.vo.BoardVO;

//process bean : DB process
public class BoardDAO implements BoardService {
	String url = "jdbc:mariadb://127.0.0.1:3306/TESTDB";
	String user = "dev";
	String pass = "dev";
	
	Connection con = null;
	Statement stat = null;
	PreparedStatement ps = null;
	DataSource ds;

	public BoardDAO() {
		try {
			InitialContext context = new InitialContext();
			ds = (DataSource) context.lookup("java:comp/env/jdbc/mariadb");
			Class.forName("org.mariadb.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<BoardVO> selectAll() {
		ArrayList<BoardVO> lis = new ArrayList<BoardVO>();
		try {

			con = ds.getConnection();
			stat = con.createStatement();
			
			String sql = "SELECT NUM, NAME, WDATE, TITLE, COUNT FROM BOARD";
			ResultSet rs = stat.executeQuery(sql);
			while (rs.next()) {
				String num = rs.getString(1);
				String name = rs.getString(2);
				Date date = rs.getDate(3);
				String title = rs.getString(4);
				int count = rs.getInt(5);
								
				BoardVO board = new BoardVO(num,name,date,title,count);
				lis.add(board);
			}
			stat.close();
			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lis;
	}

	public BoardVO selectByNum(String num){
		BoardVO bd = null;
		try {

			con = ds.getConnection();
			stat = con.createStatement();
			\String sql = "SELECT * FROM BOARD WHERE NUM='" + num + "'";
			ResultSet rs = stat.executeQuery(sql);

			while (rs.next()) {
				String nm = rs.getString(1);
				String pass = rs.getString(2);
				String name = rs.getString(3);
				Date date = rs.getDate(4);
				String title = rs.getString(5);
				String content = rs.getString(6);
				int count = rs.getInt(7);
				bd = new BoardVO(nm,pass,name,date,title,content,count);
			}
			stat.close();
			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bd;
	}
	
	public ArrayList<BoardVO> selectByCondition(String condition, String word) {
		ArrayList<BoardVO> lis = new ArrayList<BoardVO>();
		try {

			con = ds.getConnection();
			stat = con.createStatement();
			System.out.println(condition+word);
			String sql = "SELECT NUM, NAME, WDATE, TITLE, COUNT FROM BOARD WHERE "+condition+"='" + word + "'";
			

			ResultSet rs = stat.executeQuery(sql);
			while (rs.next()) {
				String num = rs.getString(1);
				String name = rs.getString(2);
				Date date = rs.getDate(3);
				String title = rs.getString(4);
				int count = rs.getInt(5);
				BoardVO board = new BoardVO(num, name, date, title, count);
				lis.add(board);
			}
			stat.close();
			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lis;
	}

	public int insertBoard(BoardVO bd) {

		try {
			con = ds.getConnection();
			stat = con.createStatement();
			String sql = "INSERT INTO BOARD VALUES(BNUM.NEXTVAL, ?, ?, SYSDATE, ?, ?, 0)";
			ps = con.prepareStatement(sql);
			
			ps.setString(1, bd.getPass());
			ps.setString(2, bd.getName());
			ps.setString(3, bd.getTitle());
			ps.setString(4, bd.getContent());

			int a = ps.executeUpdate();
			stat.close();
			con.close();
			return a;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;

	}

	public int deleteByNum(String num, String pass) {

		try {
			con = ds.getConnection();
			stat = con.createStatement();
			String sql = "DELETE FROM BOARD WHERE NUM=? and PASS=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, num);
			ps.setString(2, pass);

			int a = ps.executeUpdate();
			stat.close();
			con.close();
			return a;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;

	}
	
	public int updateBoard(String num, String pass, String title, String content){
		try {
			con = ds.getConnection();
			stat = con.createStatement();
			String sql = "UPDATE BOARD SET TITLE=?, CONTENT=? WHERE NUM=? and PASS=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, title);
			ps.setString(2, content);
			ps.setString(3, num);
			ps.setString(4, pass);

			int a = ps.executeUpdate();
			System.out.println();
			stat.close();
			con.close();
			return a;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	
	public int updateConter(String num){
			try {
			con = ds.getConnection();
			stat = con.createStatement();
			String sql = "UPDATE BOARD SET COUNT=COUNT+1 WHERE NUM=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, num);
			int a = ps.executeUpdate();
			stat.close();
			con.close();
			return a;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}
}

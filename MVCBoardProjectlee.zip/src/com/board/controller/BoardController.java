package com.board.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.board.*;
import com.board.dao.BoardDAO;
import com.board.service.BoardService;
import com.board.vo.BoardVO;

//FrontController(BoardFilter) -> BoardController -> DAO
// save the DAO output and move to JSP(forward)
public class BoardController {

	private BoardService dao;

	public BoardController() {
		dao = new BoardDAO();
	}

	public void list(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub
		ArrayList<BoardVO> list = dao.selectAll();
		req.setAttribute("list", list);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/view/list.jsp");
		
		try {
			dispatcher.forward(req, res);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void read(HttpServletRequest req, HttpServletResponse res) {
		BoardVO u = dao.selectByNum(req.getParameter("num"));

		req.setAttribute("list", u);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/view/read.jsp?name="+u.getName());
		try {
			dispatcher.forward(req, res);

		} catch (ServletException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();

		}
	}

	public void insertForm(HttpServletRequest req, HttpServletResponse res) {
		
		try {
			res.sendRedirect("view/insertForm.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void insertProcess(HttpServletRequest req, HttpServletResponse res) {
		
		String name = req.getParameter("name");
		String pass = req.getParameter("pass");
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		
		BoardVO u = new BoardVO(pass, name, title, content);
	
		int result = dao.insertBoard(u);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/view/insertSuccess.jsp?result=" + result);

		try {
			dispatcher.forward(req, res);
		} catch (ServletException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void delete(HttpServletRequest req, HttpServletResponse res) {
		try {
			res.sendRedirect("view/passInput.jsp?num=" + req.getParameter("num"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void deleteProcess(HttpServletRequest req, HttpServletResponse res) {

		int result = dao.deleteByNum(req.getParameter("num"), req.getParameter("pass"));

		// View ���� ó��
		try {
			res.sendRedirect("view/deleteSuccess.jsp?result=" + result);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void modify(HttpServletRequest req, HttpServletResponse res) {
		BoardVO u = dao.selectByNum(req.getParameter("num"));
		req.setAttribute("list", u);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/view/modifyForm.jsp");
		try {
			dispatcher.forward(req, res);

		} catch (ServletException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();

		}
	}

	public void modifyProcess(HttpServletRequest req, HttpServletResponse res) {
		String num = req.getParameter("num");
		String pass = req.getParameter("pass");
		String content = req.getParameter("content");
		System.out.println("�� : "+content);
		String title = req.getParameter("title");

		BoardVO u = new BoardVO(num, pass, null, null, title, content, 0);

		int result = dao.updateBoard(num, pass, title, content);

		// View ���� ó��
		try {
			res.sendRedirect("view/modifySuccess.jsp?result=" + result);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void search(HttpServletRequest req, HttpServletResponse res) {
		
		ArrayList<BoardVO> list = dao.selectByCondition(req.getParameter("condition"),req.getParameter("word"));
		
		req.setAttribute("list", list);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/view/search.jsp");
		try {
			dispatcher.forward(req, res);

		} catch (ServletException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();

		}
	}

	public void loginForm(HttpServletRequest req, HttpServletResponse res) {
		try {
			res.sendRedirect("view/loginForm.jsp");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void loginProcess(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession();
		session.setAttribute("id", req.getParameter("id"));	
		try {
			res.sendRedirect("list.bod");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void logoutProcess(HttpServletRequest req, HttpServletResponse res) {
		req.getSession().invalidate();
		try {
			res.sendRedirect("list.bod");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// public void search(HttpServletRequest req, HttpServletResponse res) {
	// ArrayList<Board> list =
	// dao.selectByCondition(req.getParameter("condition"),
	// req.getParameter("word"));
	// req.setAttribute("list", list);
	//
	// RequestDispatcher dispatcher =
	// req.getRequestDispatcher("/view/search.jsp");
	// try {
	// dispatcher.forward(req, res);
	// } catch (ServletException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }
	//
	// public void delete(HttpServletRequest req, HttpServletResponse res) {
	// dao.deleteById(req.getParameter("id"));
	// try {
	// res.sendRedirect("list.mvc");
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }
	//
	//
	// public void loginForm(HttpServletRequest req, HttpServletResponse res) {
	// try {
	// res.sendRedirect("view/loginForm.jsp");
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	//
	// }
	//
	// public void loginProcess(HttpServletRequest req, HttpServletResponse res)
	// {
	// // dao�� �̿��� �α��� üũ���� ������
	// // session.setAttribute("login", req.getParameter("id"));
	// // ���� ���� �� ����
	// try {
	// res.sendRedirect("list.mvc");
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	//
	// }
}

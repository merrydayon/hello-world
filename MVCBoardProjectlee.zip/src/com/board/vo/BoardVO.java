package com.board.vo;

import java.util.Date;

public class BoardVO {
	String num;
	String pass;
	String name;
	Date date;
	String title;
	String content;
	int count;
	
	public BoardVO(String num, String pass, String name, Date date, String title, String content, int count) {
		super();
		this.num = num;
		this.pass = pass;
		this.name = name;
		this.date = date;
		this.title = title;
		this.content = content;
		this.count = count;
	}
	
	public BoardVO(String num,String name,Date date,String title,int count){
		this.num = num;
		this.name = name;
		this.date = date;
		this.title = title;
		this.count = count;
		
	}
	public BoardVO(String pass,String name,String title,String content){
		this.num = num;
		this.name = name;
		this.pass = pass;
		this.date = date;
		this.title = title;
		this.count = count;
		this.content = content;
		
	}
	
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	
}

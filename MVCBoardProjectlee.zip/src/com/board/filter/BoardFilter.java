package com.board.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.controller.BoardController;
import com.board.dao.BoardDAO;

// receive the all of client requests, then pass the job process to Controller

public class BoardFilter implements Filter {

  
	public void destroy() {

	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse res = (HttpServletResponse)response;
		
		String reqString = req.getServletPath();
		System.out.println(reqString);
		BoardController uc = new BoardController();
		if(reqString.equals("/list.bod")){
			uc.list(req,res);
		}else if(reqString.equals("/read.bod")){
			new BoardDAO().updateConter(req.getParameter("num"));
			uc.read(req,res);
		}else if(reqString.equals("/insertForm.bod")){
			uc.insertForm(req,res);
		}else if(reqString.equals("/insertProcess.bod")){
			uc.insertProcess(req,res);
		}else if(reqString.equals("/search.bod")){
			uc.search(req,res);
		}else if(reqString.equals("/delete.bod")){
			uc.delete(req,res);		
		}else if(reqString.equals("/deleteProcess.bod")){
			uc.deleteProcess(req,res);		
		}else if(reqString.equals("/modifyForm.bod")){
			uc.modify(req,res);		
		}else if(reqString.equals("/modifyProcess.bod")){
			uc.modifyProcess(req,res);		
		}else if(reqString.equals("/loginForm.bod")){
			uc.loginForm(req,res);
		}else if(reqString.equals("/loginProcess.bod")){
			uc.loginProcess(req,res);
		}else if(reqString.equals("/logout.bod")){
			uc.logoutProcess(req,res);
		}else{
			
		}
		
	}

	public void init(FilterConfig fConfig) throws ServletException {

	}

}
